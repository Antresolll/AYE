sas = "sas"
print(sas.encode('utf-8'))
